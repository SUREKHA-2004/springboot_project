package com.bigbasket.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity

public class Bigbasket {
	@Id
	private int id;
	private String name;
	private String type;
	private long productCode;
	private String netweight;
	private String manufacturer;
	private float mrp;
	private float offerprice;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public long getProductCode() {
		return productCode;
	}
	public void setProductCode(long productCode) {
		this.productCode = productCode;
	}
	public String getNetweight() {
		return netweight;
	}
	public void setNetweight(String netweight) {
		this.netweight = netweight;
	}
	public String getManufacturer() {
		return manufacturer;
	}
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}
	public float getMrp() {
		return mrp;
	}
	public void setMrp(float mrp) {
		this.mrp = mrp;
	}
	public float getOfferprice() {
		return offerprice;
	}
	public void setOfferprice(float offerprice) {
		this.offerprice = offerprice;
	}
	
	
	
	public Bigbasket() {
		super();
	}
	public Bigbasket(int id, String name, String type, long productCode, String netweight, String manufacturer,
			float mrp, float offerprice) {
		super();
		this.id = id;
		this.name = name;
		this.type = type;
		this.productCode = productCode;
		this.netweight = netweight;
		this.manufacturer = manufacturer;
		this.mrp = mrp;
		this.offerprice = offerprice;
	}
	@Override
	public String toString() {
		return "Bigbasket [id=" + id + ", name=" + name + ", type=" + type + ", productCode=" + productCode
				+ ", netweight=" + netweight + ", manufacturer=" + manufacturer + ", mrp=" + mrp + ", offerprice="
				+ offerprice + "]";
	}
	
	
	
}
