package com.bigbasket.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bigbasket.demo.model.Bigbasket;
import com.bigbasket.demo.model.BigbasketLoginModel;
import com.bigbasket.demo.model.BigbasketModel2;
import com.bigbasket.demo.service.BigbasketService;

@RestController
public class BigbasketController {
	@Autowired
	BigbasketService bigbasketService;
	
	
	@GetMapping(value = "/fetchBigbaskets")
	public List<Bigbasket>getAllBigbaskets()
	{
		List<Bigbasket> bigbasketList = bigbasketService.getAllBigbaskets();
		return bigbasketList;
	}
	@PostMapping(value="/saveBig")
	
	public Bigbasket saveBigbasket(@RequestBody Bigbasket s)
	{
		return bigbasketService.saveBigbasket(s);
	}
	@PutMapping(value="/updateBigbasket")
	public Bigbasket updateBigbasket(@RequestBody Bigbasket s)
	{
		return bigbasketService.saveBigbasket(s);
	}
	@DeleteMapping("/deleteBigbasket/{id}/desc")
	public void deleteBigbasket(@PathVariable("id")int id)
	{
		bigbasketService.deleteBigbasket(id);
	} 
	@GetMapping(value="/getBigbasket/{id}")
	public Bigbasket getBigBasket(@PathVariable("id")int id)
	{
		return bigbasketService.getBigBasket(id);
	}
	//sorting
	@GetMapping(value="/sort/{id}")
	public List<Bigbasket> sortBasket(@PathVariable("id") String id)
	{
		return bigbasketService.sortBasket(id);
	}
	@GetMapping(value="/bigbasketSorting/{id}")
	public List<Bigbasket> sortBigbasket(@PathVariable("id") String id)
	{
		return bigbasketService.sortBigbasket(id);
	}
	@GetMapping(value="/bigbasketSorting1/{id}")
	public List<Bigbasket> sortBigbasket1(@PathVariable("id") String id)
    {
		return bigbasketService.sortBigbasket1(id);
	}
	@GetMapping(value="pagenation/{offset}/{pagesize}")
	public List<Bigbasket> getBigbasketDetails(@PathVariable int offset,@PathVariable int pagesize)
	{
		return bigbasketService.getBigbasketDetails(offset,pagesize);
	}
	@GetMapping("/pagenationSorting/{offset}/{pagesize}/{id}")
	public List<Bigbasket>getBigbasketSort(@PathVariable int offset,@PathVariable int pagesize,@PathVariable String id)
	{
		return bigbasketService.getBigbasketSort(offset,pagesize,id);
	}
	
	@GetMapping(value="/getlogin")
	public List<BigbasketLoginModel> getUser()
	{
		return bigbasketService.getUser();
	}
	
	/*@PostMapping(value="/addUserLogin")
	public BigbasketLoginModel saveUser(@RequestBody BigbasketLoginModel l)
	{
		return bigbasketService.saveUser(l);
	}*/
	
	@PostMapping(value="/checkLogin")
	public String validateUser(@RequestBody BigbasketLoginModel l)
	{
		
		return bigbasketService.validateUser(l.getUsername(),l.getPassword());
	}
	@GetMapping("/fetchByDept")
	public List<Bigbasket> getStudentsByDept(@RequestParam String name)
	{
		return bigbasketService.getStudentsByDept(name);
	}
	@GetMapping("/fetchByDept/{type}/{name}")
	public List<Bigbasket> getStudentsByDept(@PathVariable String type, @PathVariable String name)
	{
		return bigbasketService.getStudentsByDept(type,name);
	}
	@DeleteMapping("/deleteStudentByName/{name}")
    public String deleteStudentByName(@PathVariable String name)
    {
 	   int result = bigbasketService.deleteStudentByName(name);
 	   if(result>0)
 		     return "record deleted";
 	   else
 		     return "Problem occured while deleting";
    }   
    @PutMapping("/updateStudentByName/{type}/{name}")
    public String updateStudentByName(@PathVariable String type,@PathVariable String name)
    {
 	   int res = bigbasketService.updateStudentByName(type,name);
 	   if(res>0)
 		      return "Student record updated";
 	   else
 		    return "Problem occured";
 	}
  //one to one
  	@GetMapping(value="fetchAllProjectDetails")
  	public List<BigbasketModel2> fetchAllProjectDetails()
  	{
  		return bigbasketService.fetchAllProjectDetails();
  	}
  	
  	@PostMapping(value="/saveProjectDetails")
  	public BigbasketModel2 saveProjectDetails(@RequestBody BigbasketModel2 p )
  	{
  		return bigbasketService.saveProjectDetails(p);
  	}
}
