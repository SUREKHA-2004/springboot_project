package com.bigbasket.demo.repository;

public interface BigbasketModel1Repository {

}
