package com.bigbasket.demo.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import com.bigbasket.demo.model.Bigbasket;
import com.bigbasket.demo.model.BigbasketLoginModel;
import com.bigbasket.demo.model.BigbasketModel2;
import com.bigbasket.demo.repository.BigbasketLoginRepository;
import com.bigbasket.demo.repository.BigbasketModel2Repository;
import com.bigbasket.demo.repository.BigbasketRepository;

import jakarta.transaction.Transactional;


@Service

public class BigbasketService {
     @Autowired 
     BigbasketRepository bigbasketRepository;
     
     @Autowired 
     BigbasketLoginRepository loginRepository;
     
     @Autowired
     BigbasketModel2Repository model2Repository;
     
    public List<Bigbasket> getAllBigbaskets()
    {
    	List<Bigbasket>bigbasketList=bigbasketRepository.findAll();
    	return bigbasketList;
     }
    public Bigbasket saveBigbasket(Bigbasket s)
    {
    	Bigbasket obj=bigbasketRepository.save(s);
    	return obj;
}
public Bigbasket updateBigbasket(Bigbasket s)
{
	Bigbasket obj1=bigbasketRepository.save(s);
	return obj1;
}
public void deleteBigbasket(int id)
{
    bigbasketRepository.deleteById(id);
}
public Bigbasket getBigBasket(int id )   
{
	Bigbasket s = bigbasketRepository.findById(id).get();
	return s;  
}
//sorting
public List<Bigbasket> sortBasket(String id) {
	
	 return bigbasketRepository.findAll(Sort.by(id));
}
public List<Bigbasket> sortBigbasket(String id) {
	 return bigbasketRepository.findAll(Sort.by(id).ascending());
}
public List<Bigbasket> sortBigbasket1(String id) {
	 return bigbasketRepository.findAll(Sort.by(id).descending());
}
public List<Bigbasket> getBigbasketDetails(@PathVariable int offset,@PathVariable int pagesize) {
	Page <Bigbasket> page=bigbasketRepository.findAll(PageRequest.of(offset, pagesize));
	return page.getContent();
}
public List<Bigbasket> getBigbasketSort(int offset, int pagesize, String id) {
	PageRequest paging=PageRequest.of(offset, pagesize,Sort.by(id));
	Page<Bigbasket>page=bigbasketRepository.findAll(paging);
	return page.getContent() ;
}


public String validateUser(String username, String password) 
{
	BigbasketLoginModel u = loginRepository.findByUsername(username);
	if(u==null)
	{
		return"Invalid user";
	}
	else
	{
		if(u.getPassword().equals(password))
		{
			return"Login success";
		}
		else
		{
			return"Login failed";
		}
	}
	}
	public BigbasketLoginModel saveUser(BigbasketLoginModel u) 
	{
		return loginRepository.save(u);
	}
	public List<BigbasketLoginModel> getUser()
	{
		
		return loginRepository.findAll();
	}

	public List<Bigbasket> getStudentsByDept(String type,String name)
	  {
		  return bigbasketRepository.getStudentsByType(type, name);
	  }
	@Transactional 
	public int deleteStudentByName(String name)
	{
 	return bigbasketRepository.deleteStudentByName(name);
	}
	@Transactional
	public int updateStudentByName(String type,String name)
	{
		return bigbasketRepository.updateStudentByType(type, name);
	}
	public List<Bigbasket> getStudentsByDept(String name) {
		return bigbasketRepository.getStudentsByName(name);
	}
	public List<BigbasketModel2> fetchAllProjectDetails()
	{
		 return model2Repository.findAll();
	}
	
	public BigbasketModel2 saveProjectDetails(BigbasketModel2 p)
	{
		return model2Repository.save(p);
	}
}



 



