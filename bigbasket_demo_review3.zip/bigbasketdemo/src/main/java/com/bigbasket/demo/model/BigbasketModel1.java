package com.bigbasket.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class BigbasketModel1 {
    @Id
    int customer_number;
    String dob;
    int age;
	public int getCustomer_number() {
		return customer_number;
	}
	public void setCustomer_number(int customer_number) {
		this.customer_number = customer_number;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
}
