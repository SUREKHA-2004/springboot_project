package com.bigbasket.demo.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


import com.bigbasket.demo.model.BigbasketLoginModel;

@Repository
public interface BigbasketLoginRepository extends JpaRepository<BigbasketLoginModel,Integer> {

	public BigbasketLoginModel findByUsername(String username);
}
