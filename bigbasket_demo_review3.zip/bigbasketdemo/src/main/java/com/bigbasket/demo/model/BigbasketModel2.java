package com.bigbasket.demo.model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;

@Entity
public class BigbasketModel2 {
	@Id
	int sale_id;
	float ratings;
	String main_ingredient;
	public int getSale_id() {
		return sale_id;
	}
	public void setSale_id(int sale_id) {
		this.sale_id = sale_id;
	}
	public float getRatings() {
		return ratings;
	}
	public void setRatings(float ratings) {
		this.ratings = ratings;
	}
	public String getMain_ingredient() {
		return main_ingredient;
	}
	public void setMain_ingredient(String main_ingredient) {
		this.main_ingredient = main_ingredient;
	}
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="customer_care_id")
	private BigbasketModel1 bigbasketModel1;
	public BigbasketModel1 getBigbasketModel1() {
		return bigbasketModel1;
	}
	public void setBigbasketModel1(BigbasketModel1 bigbasketModel1) {
		this.bigbasketModel1 = bigbasketModel1;
	}
	
}
