package com.bigbasket.demo.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.bigbasket.demo.model.Bigbasket;
@Repository
public interface BigbasketRepository extends JpaRepository<Bigbasket, Integer> {
	@Query("select s from Bigbasket s where s.type=?1 and s.name=?2")
    public List<Bigbasket> getStudentsByType(String type,String name);
   //named parameter
   @Query("select s from Bigbasket s where s.name=:name")
   public List<Bigbasket> getStudentsByName(String name);
	//DML
	@Modifying
	@Query("delete from Bigbasket s where s.name=?1")
	public int deleteStudentByName(String name);
   @Modifying
   @Query("update Bigbasket s set s.type=?1 where s.name=?2")
   public int updateStudentByType(String type,String name);
	
}
