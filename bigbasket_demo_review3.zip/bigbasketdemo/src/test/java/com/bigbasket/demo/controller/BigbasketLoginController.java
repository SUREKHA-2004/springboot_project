package com.bigbasket.demo.controller;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class BigbasketLoginController {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
